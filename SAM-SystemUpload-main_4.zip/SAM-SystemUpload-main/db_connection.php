<?php
	$servername = "localhost";
					$username = "root";
					$password = "";
					$databasename = "sam";

    		$connect = mysqli_connect($servername,$username,$password,$databasename);

	
?>