<!DOCTYPE html>
	<html>
		<head>
			<script src="https://use.fontawesome.com/d1341f9b7a.js"></script>
			<meta charset="utf-8">
			<title>Developers Profile</title>
		</head>

	<style>
		body {
			background-image: url(images/background.jpg);
			background-repeat: no-repeat;
			background-size: cover;
			background-attachment: fixed;
			color: white;
			}


		.back i {
			color: white;
			font-size: 20px;
			padding: 10px;
			transition: all ease-in-out 250ms;
			text-decoration: none;
			text-align: center;
			background-color: black;
			opacity: 0.5;
			border-radius: 10px;
		}

		.back i:hover {
			color: #cc0066;
			background-color: white;
		}

		.back {
			text-align: center;
		}

	</style>
		<br>
			 <br>
				 <br>
					<center> <table border="1" style="background-color: rgba(0,0,0,0.4);"> <td>
	<center>
		<table border="0">
			<td width="570" height="100" style="padding-left: 20px;">
				<font size="7" face="Perpetua">
					<b> Erika Mae L. Serquiña </b> <br>
				</font>
				<font size="5" face="Perpetua">
					Address: Quezon St., Casaratan, San Nicolas, Pangasinan <br>
					Contact No.: 09123456789 <br>
					E-mail: erikalopezserquina@gmail.com <br>
				</font>
			</td>
			<td width = "200" height = "100">
				<img src="images/resume.jpg" align="right" width="200" height="200">
			</td>
		</table>
	</center>

	<hr size="7" width="780" color="white">

	<center>
		<table border="0">
			<tr>
				<td colspan="3" style="padding-left: 20px;">
					<p align="left">
						<font size="5" face="Perpetua">
							<b> PERSONAL INFORMATION </b>
						</font>
					</p>
				</td>
			</tr>
			<tr>
				<td width="200" style="padding-left: 20px;">
					<font size="5" face="Perpetua">
						Date of Birth <br>
						Place of Birth <br>
						Age <br>
						Sex <br>
						Religion <br>
						Civil Status <br>
						Father's Name <br>
						Mother's Name <br>				
					</font>
				</td>
				<td width="100">
					<font size="5" face="Perpetua">
						: <br>
						: <br>
						: <br>
						: <br>
						: <br>
						: <br>
						: <br>
						: <br>
					</font>
				</td>
				<td width="470">
					<font size="5" face="Perpetua">
						May 18, 2001 <br>
						San Nicolas, Pangasinan <br>
						20 Years Old <br>
						Female <br>
						Roman Catholic <br>
						Single <br>
						Menzi C. Serquiña <br>
						Jasmin L. Serquiña <br>
					</font>
				</td>
			</tr>
		</table>
	</center>
	<br> 
	<center>
		<table border="0">
			<tr>
				<td width="790" style="padding-left: 20px;">
					<p align="left">
						<font size="5" face="Perpetua">
							<b> GENERAL SKILLS </b>
								<br> * Leadership 
								<br> * Teamwork 
								<br> * Good Communication
								<br>
									<br>
										<b> TECHNICAL SKILLS </b>
											<br> * Software (Adobe Photoshop, Microsoft Office)
											<br> * Hardware (Assembly, Peripherals, Maintenance)
											<br> * Programming Languages (C++, HTML)
												<br>
											<br>
										<b> INTEREST </b> 
									<br>* Artifial Intelligence 
								<br>* Video Games 
							<br>* Sports (Table Tennis)
						</font>
					</p>
				</td>
			</tr>
		</table>
	</center>
	<br>
	<center>
		<table border="0">
			<tr>
				<td colspan="3" style="padding-left: 20px;">
					<p>
						<font size="5" face="Perpetua">
							<b> ACADEMIC BACKGROUND </b>
						</font>
					</p>
				</td>
			</tr>
			<tr>
				<td width="200" style="padding-left: 20px;">
					<p>
						<font size="5" face="Perpetua">
							<b> Tertiary </b>
						</font>
					</p>
				</td>
				<td style="padding-left: 20px;">
					<p>
						<font size="5" face="Perpetua">
							: <br>
							: <br>
							: <br>
						</font>
					</p>
				</td>
				<td>
					<p>
						<font size="5" face="Perpetua">
							Urdaneta City University <br>
							San Vicente West, Urdaneta, Pangasinan <br>
							2019 - PRESENT <br>
						</font>
					</p>
				</td>
			</tr>
			<tr>
				<td style="padding-left: 20px;">
					<p>
						<font size="5" face="Perpetua">
							<b>Secondary</b>
						</font>
					</p>
				</td>
				<td>
					<p>
						<font size="5" face="Perpetua">
							: <br>
							: <br>
							: <br>
						</font>
					</p>
				</td>
				<td>
					<p>
						<font size="5" face="Perpetua">
							Red Arrow High School <br>
							Nagkaysa, San Nicolas, Pangasinan <br>
							2018 - 2019 <br>
						</font>
					</p>
				</td>
			</tr>
			<tr>
				<td style="padding-left: 20px;">
					<p>
						<font size="5" face="Perpetua">
							<b>Primary</b>
						</font>
					</p>
				</td>
				<td width="100">
					<p>
						<font size="5" face="Perpetua">
							: <br>
							: <br>
							: <br>
						</font>
					</p>
				</td>
				<td width="480">
					<p>
						<font size="5" face="Perpetua">
							East Central Elementary School <br>
							Pob East, San Nicolas, Pangasinan <br>
							2012 - 2013 <br>
						</font>
					</p>
				</td>
			</tr>
		</table>
	</center>
</td></table> </center>

	<br>
	<br>
	<br>
		<div class="back">
			<a href="gallery.php" style="float: left; margin-left: 520px"><i class="fa fa-picture-o" aria-hidden="true" > Gallery</i> </a>
			<a href="index.php" style="float: right; margin-right: 500px"><i class="fa fa-sign-out" aria-hidden="true" > Logout</i> </a>	
		</div>

	<br><br><br><br>

</body>
</html>


